This is website which analyses the strength of an argument for logical coherence (Logos), credibility (Ethos) and emotional appeal (Pathos).
